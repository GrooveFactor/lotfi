USE Revision;


CREATE TABLE Host(
host_ID int,
host_Name varchar(255),
host_IP varchar(255),
satus varchar(255),
last_date_connection date
);

INSERT INTO Host VALUES('1', 'Ubuntu_16.04', '121.83.158.243', 'started', '2019-12-09');
INSERT INTO Host VALUES('2', 'RedHat', '79.30.50.207', 'stopped', '2018-11-19');
INSERT INTO Host VALUES('3', 'Wind10', '125.69.100.61', 'stopped', '2019-06-25');
INSERT INTO Host VALUES('4', 'Azure', '54.114.111.90', 'stopped', '2018-12-03');
INSERT INTO Host VALUES('5', 'Ubuntu_18.04', '81.99.131.160', 'stopped', '2019-10-28');
