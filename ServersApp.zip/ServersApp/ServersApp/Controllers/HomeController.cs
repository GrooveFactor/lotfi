﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServersApp.Models;
using Microsoft.Extensions.Configuration;

namespace ServersApp.Controllers
{
    public class HomeController : Controller
    {
        public HostDAL hostDAL = null;
        public HomeController(IConfiguration _configuration)
        {
            hostDAL = new HostDAL(_configuration);
        }
        public IActionResult Index()
        {
            List<Host> hosts = hostDAL.GetHosts();           
            return View(hosts);
        }

        
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult CreateSubmitted(Host host)
        {
            if (host.Host_ip != null)
            {
                hostDAL.CreateHost(host);
                return RedirectToAction("Index");
            }
            else
            {
                ViewBag.Message = "Création échouée!";
                return View("Create");
            }           
        }

        public IActionResult Status()
        {
            return View();
        }

        public IActionResult StatusSubmitted(string ip)
        {
            Host host = hostDAL.GetHostByIp(ip);
            if(host.Host_ip == null)
            {
                ViewBag.Message = "adresse est nulle ou erronee";
            }
            else
            {
                ViewBag.Message = host.Status;
            }
            return View("Status");
        }

        public IActionResult ChangeStatus()
        {
            List<Host> hosts = hostDAL.GetHosts();
            ViewBag.Hosts = hosts;
            return View();
        }

        public IActionResult ChangeStatusSubmitted(int id, string status)
        {
            List<Host> hosts = hostDAL.GetHosts();
            ViewBag.Hosts = hosts;
            if (status == null)
            {
                ViewBag.Message = "Veuillez choisir demarrer ou arreter l'host";
                return View("ChangeStatus");
            }
            else 
            {
                Host host = hostDAL.GetHostById(id);
                if(host.Status != status)
                {
                    if(status == "stopped")
                    {
                        DateTime currentDate = DateTime.Now;
                        hostDAL.UpdateHostByIdWithDate(id, status, currentDate);
                    }
                    else
                    {
                        hostDAL.UpdateHostById(id, status);
                    }

                }
                return RedirectToAction("Index");
            }           
        }


        public IActionResult CleanServer()
        {
            List<Host> hosts = hostDAL.GetOldStoppedHosts();
            return View(hosts);
        }

        public IActionResult ExecuteCleanServer()
        {
            hostDAL.DeleteOldStoppedHosts();
            return RedirectToAction("Index");
        }

    }
}
