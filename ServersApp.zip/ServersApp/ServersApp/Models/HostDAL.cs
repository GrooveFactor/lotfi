﻿using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;

namespace ServersApp.Models
{
    public class HostDAL
    {
        // database connection configurations
        public static IConfiguration Configuration { get; set; }

        private string connectionString;
        public HostDAL(IConfiguration _configuration) { 
            Configuration = _configuration;
            connectionString = Configuration.GetConnectionString("MyDB");
        }

        public List<Host> GetHosts()
        {
            List<Host> hosts = new List<Host>();

            SqlConnection conn = new SqlConnection(connectionString);

            try
            {
                string sql = "SELECT * FROM host ";
                SqlCommand cmd = new SqlCommand(sql, conn);

                conn.Open();

                SqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    Host host = new Host();
                    host.Host_id = rdr.GetInt32(0);
                    host.Host_name = rdr.GetString(1);
                    host.Host_ip = rdr.GetString(2);
                    host.Status = rdr.GetString(3);
                    host.Last_date_connection = rdr.GetDateTime(4);

                    hosts.Add(host);
                }

                conn.Close();
            }
            catch (SqlException e)
            {

                Debug.WriteLine(e.ToString());
            }
            return hosts;
        }

        public Host GetHostById(int id)
        {
            Host host = new Host();
            SqlConnection conn = new SqlConnection(connectionString);

            try
            {
                string sql = "SELECT * FROM host WHERE host_id = '" + id + "' ";
                SqlCommand cmd = new SqlCommand(sql, conn);
                conn.Open();

                SqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    host.Host_id = rdr.GetInt32(0);
                    host.Host_name = rdr.GetString(1);
                    host.Host_ip = rdr.GetString(2);
                    host.Status = rdr.GetString(3);
                    host.Last_date_connection = rdr.GetDateTime(4);
                }
                conn.Close();
            }
            catch (SqlException e)
            {

                Debug.WriteLine(e.ToString());
            }
            return host;
        }
        // get the host from its ip address
        public Host GetHostByIp(string ip)
        {
            Host host = new Host();
            SqlConnection conn = new SqlConnection(connectionString);

            try
            {
                string sql = "SELECT * FROM host WHERE host_ip = '" + ip + "' ";
                SqlCommand cmd = new SqlCommand(sql, conn);
                conn.Open();

                SqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    host.Host_id = rdr.GetInt32(0);
                    host.Host_name = rdr.GetString(1);
                    host.Host_ip = rdr.GetString(2);
                    host.Status = rdr.GetString(3);
                    host.Last_date_connection = rdr.GetDateTime(4);
                }
                conn.Close();
            }
            catch (SqlException e)
            {

                Debug.WriteLine(e.ToString());
            }
            return host;
        }
        // list all obsolete hosts before deleting them
        public List<Host> GetOldStoppedHosts()
        {
            List<Host> hosts = new List<Host>();

            SqlConnection conn = new SqlConnection(connectionString);

            try
            {
                var currentDate = DateTime.Now;
                var oldDate = currentDate.AddYears(-2);
                string sql = "SELECT * FROM host WHERE status = 'stopped' AND last_date_connection < '" + oldDate + "'";
                SqlCommand cmd = new SqlCommand(sql, conn);

                conn.Open();

                SqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    Host host = new Host();
                    host.Host_id = rdr.GetInt32(0);
                    host.Host_name = rdr.GetString(1);
                    host.Host_ip = rdr.GetString(2);
                    host.Status = rdr.GetString(3);
                    host.Last_date_connection = rdr.GetDateTime(4);

                    hosts.Add(host);
                }

                conn.Close();
            }
            catch (SqlException e)
            {

                Debug.WriteLine(e.ToString());
            }
            return hosts;
        }

        // add a new host
        public void CreateHost(Host host)
        {
            SqlConnection conn = new SqlConnection(connectionString);

            try
            {
                string sql = "INSERT INTO host (host_name, host_ip, status, last_date_connection) VALUES ('"
                    + host.Host_name + "','"
                    + host.Host_ip + "','"
                    + host.Status + "','"
                    + host.Last_date_connection + "')";
                SqlCommand cmd = new SqlCommand(sql, conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (SqlException e)
            {

                Debug.WriteLine(e.ToString());
            }
        }

        // from stopped to started
        public void UpdateHostById(int id, string status)
        {
            SqlConnection conn = new SqlConnection(connectionString);

            try
            {
                string sql = "UPDATE host SET " +
                    "status = '" + status + "'" +
                    "WHERE host_id = " + id;
                SqlCommand cmd = new SqlCommand(sql, conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (SqlException e)
            {

                Debug.WriteLine(e.ToString());
            }
        }

        // from started to stopped
        public void UpdateHostByIdWithDate(int id, string status, DateTime d)
        {
            SqlConnection conn = new SqlConnection(connectionString);

            try
            {
                string sql = "UPDATE host SET " +
                            "status = '" + status + "'," +
                            "last_date_connection = '" + d + "'" +
                            "WHERE host_id = " + id;
                SqlCommand cmd = new SqlCommand(sql, conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (SqlException e)
            {

                Debug.WriteLine(e.ToString());
            }
            
        }

        // clean server
        public void DeleteOldStoppedHosts()
        {
            SqlConnection conn = new SqlConnection(connectionString);

            try
            {
                var currentDate = DateTime.Now;
                var oldDate = currentDate.AddYears(-3);
                string sql = "DELETE FROM host WHERE status = 'stopped' AND last_date_connection < '" + oldDate + "'";
                SqlCommand cmd = new SqlCommand(sql, conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (SqlException e)
            {

                Debug.WriteLine(e.ToString());
            }
        }
    }
}
