﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ServersApp.Models
{
    public class Host
    {
        public int Host_id { get; set; }

        public string Host_name { get; set; }

        public string Host_ip { get; set; }

        public string Status { get; set; }

        public DateTime Last_date_connection { get; set; }
    }
}
